Petaca
======
Petaca is an ad hoc collection of modern Fortran modules that provide
broadly useful capabilities -- things that I have found myself using
repeatedly across many projects. A unifying feature of the modules is
their object-oriented interfaces and implementation.

Read the documentation on [readthedocs.org](http://petaca.readthedocs.io/)
(under development).
