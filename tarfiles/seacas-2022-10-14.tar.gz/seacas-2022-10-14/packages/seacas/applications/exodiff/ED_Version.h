// Copyright(C) 1999-2022 National Technology & Engineering Solutions
// of Sandia, LLC (NTESS).  Under the terms of Contract DE-NA0003525 with
// NTESS, the U.S. Government retains certain rights in this software.
//
// See packages/seacas/LICENSE for details
#ifndef ED_Version_h
#define ED_Version_h

static std::string version("3.22");
static std::string verdate("2022-09-27");

#endif // ED_Version_h
