// Copyright(C) 1999-2020, 2022 National Technology & Engineering Solutions
// of Sandia, LLC (NTESS).  Under the terms of Contract DE-NA0003525 with
// NTESS, the U.S. Government retains certain rights in this software.
//
// See packages/seacas/LICENSE for details
#ifndef EJ_Version_h
#define EJ_Version_h

static char const *qainfo[] = {
    "ejoin",
    "2022/01/24",
    "1.5.7",
};

#endif
