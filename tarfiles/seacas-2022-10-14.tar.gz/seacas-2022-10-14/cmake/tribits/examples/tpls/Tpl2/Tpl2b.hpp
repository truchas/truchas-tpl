#ifndef TPL2B_HPP
#define TPL2B_HPP

#include <string>

namespace Tpl2 {

/** \brief . */
std::string b_itsme();

/** \brief . */
std::string b_deps();

} // namespace tpl2

#endif // TPL2B_HPP
