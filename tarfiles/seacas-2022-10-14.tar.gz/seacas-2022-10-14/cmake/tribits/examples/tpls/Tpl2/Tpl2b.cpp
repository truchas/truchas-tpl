#include "Tpl2b.hpp"

std::string Tpl2::b_itsme()
{
  return "Tpl2b";
}

std::string Tpl2::b_deps()
{
  return "no deps";
}
