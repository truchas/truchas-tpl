#ifndef TPL1_HPP
#define TPL1_HPP

#include <string>

namespace Tpl1 {

/** \brief . */
std::string itsme();

} // namespace tpl1

#endif // TPL1_HPP
