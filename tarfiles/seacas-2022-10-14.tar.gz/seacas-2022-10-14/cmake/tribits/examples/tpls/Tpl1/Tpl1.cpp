#include "Tpl1.hpp"

std::string Tpl1::itsme()
{
  return "tpl1";
}
