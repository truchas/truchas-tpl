#ifndef PACKAGE3_HPP
#define PACKAGE3_HPP


#include "Package3_config.h"

#include <ostream>


namespace Package3 {

/** \brief . */
std::string itsme();

/** \brief . */
std::string deps();

} // namespace Package3


#endif // PACKAGE3_HPP
