#ifndef PACKAGE2_HPP
#define PACKAGE2_HPP


#include "Package2_config.h"
#include <ostream>

namespace Package2 {

/** \brief . */
std::string itsme();

/** \brief . */
std::string deps();

} // namespace Package2


#endif // PACKAGE2_HPP
