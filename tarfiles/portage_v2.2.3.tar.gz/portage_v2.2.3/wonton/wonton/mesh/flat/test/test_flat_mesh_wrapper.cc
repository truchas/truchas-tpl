/*
This file is part of the Ristra Wonton project.
Please see the license file at the root of this repository, or at:
    https://github.com/laristra/wonton/blob/master/LICENSE
*/

#include "wonton/mesh/jali/jali_mesh_wrapper.h"
#include "wonton/mesh/flat/flat_mesh_wrapper.h"

#include <algorithm>
#include <iostream>

#include "gtest/gtest.h"
#include "mpi.h"

#include "Mesh.hh"
#include "MeshFactory.hh"

#include "wonton/support/Point.h"

using std::abs;

#define TOL 1.0e-12

/*!
  @file test_flag_mesh_wrapper.cc
  @brief Unit tests for the flat mesh wrapper class
 */


/*!
  @brief Unit test for basic routines in Flat_Mesh_Wrapper in 3D
 */
TEST(Flat_Mesh_Wrapper, basic_routines_3d) {
  Jali::MeshFactory mf(MPI_COMM_WORLD);
  mf.included_entities({Jali::Entity_kind::EDGE,
                        Jali::Entity_kind::FACE,
                        Jali::Entity_kind::WEDGE,
                        Jali::Entity_kind::CORNER});
  std::shared_ptr<Jali::Mesh> mesh = mf(0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 2, 2, 2);
  ASSERT_TRUE(mesh != NULL);
  Wonton::Jali_Mesh_Wrapper mesh_wrapper(*mesh);
  Wonton::Flat_Mesh_Wrapper<> mesh_flat;
  mesh_flat.initialize(mesh_wrapper);
  
  ASSERT_EQ(3, mesh_flat.space_dimension());

  // Test cells, nodes, and faces of flat mesh
  ASSERT_EQ(8, mesh_flat.num_owned_cells());
  ASSERT_EQ(8, mesh_flat.num_entities(Wonton::Entity_kind::CELL));
  ASSERT_EQ(27, mesh_flat.num_owned_nodes());
  ASSERT_EQ(27, mesh_flat.num_entities(Wonton::Entity_kind::NODE));
  ASSERT_EQ(36, mesh_flat.num_owned_faces());
  ASSERT_EQ(36, mesh_flat.num_entities(Wonton::Entity_kind::FACE));

  // Check coordinates
  // List coordinates of cell 0 - others are equal to this
  // with a shift
  std::vector<Wonton::Point<3>> cell0Coords =
    {{0.0, 0.0, 0.0},  {0.0, 0.0, 0.5},  {0.0, 0.5, 0.0},  {0.0, 0.5, 0.5},
     {0.5, 0.0, 0.0},  {0.5, 0.0, 0.5},  {0.5, 0.5, 0.0},  {0.5, 0.5, 0.5}};
  for (int c=0; c<8; ++c) {
    std::vector<Wonton::Point<3>> pplist;
    mesh_flat.cell_get_coordinates(c, &pplist);
    ASSERT_EQ(unsigned(8), pplist.size());
    std::sort(pplist.begin(), pplist.end());
    double dx = (c & 4 ? 0.5 : 0.0);
    double dy = (c & 2 ? 0.5 : 0.0);
    double dz = (c & 1 ? 0.5 : 0.0);
    for (int n=0; n<8; ++n) {
      ASSERT_EQ(cell0Coords[n][0] + dx, pplist[n][0]);
      ASSERT_EQ(cell0Coords[n][1] + dy, pplist[n][1]);
      ASSERT_EQ(cell0Coords[n][2] + dz, pplist[n][2]);
    }
  }

  // Test global ids
  std::vector<Wonton::GID_t>& gids = mesh_flat.get_global_cell_ids();
  for (int c=0; c<8; ++c)
    ASSERT_EQ(c, gids[c]);

  // Test decompose_cell_into_tets()
  std::vector<std::array<Wonton::Point<3>, 4>> tcoords;
  mesh_flat.decompose_cell_into_tets(0, &tcoords, true);
  ASSERT_EQ(tcoords.size(), unsigned(24));

  // Test centroids
  Wonton::Point<3> centroid;
  mesh_flat.cell_centroid(0, &centroid);
  for (int d=0; d<3; ++d)
    ASSERT_NEAR(0.25, centroid[d], TOL);

  // Test cell and node radius
  double cradius, nradius;
  Wonton::cell_radius<3>(mesh_flat, 0, &cradius);
  ASSERT_NEAR(sqrt(3.0)/4., cradius, TOL);
  Wonton::node_radius<3>(mesh_flat, 0, &nradius);
  ASSERT_NEAR(sqrt(3.0)/2., nradius, TOL);

  // Test cell_volume()
  for (int c=0; c<8; ++c)
    ASSERT_NEAR(mesh_flat.cell_volume(c), 0.125, TOL);

  // Test cell neighbors
  for (int c=0; c<8; ++c) {
    std::vector<int> adjcells;
    mesh_flat.cell_get_node_adj_cells(c, Wonton::Entity_type::ALL,
                                      &adjcells);
    ASSERT_EQ(unsigned(7), adjcells.size());
    std::sort(adjcells.begin(), adjcells.end());
    for (int n=0; n<7; ++n)
      ASSERT_EQ(n + (n >= c ? 1 : 0), adjcells[n]);
  }

  // Test node neighbors
  for (int n=0; n<27; ++n) {
    std::vector<int> adjnodes;
    mesh_flat.node_get_cell_adj_nodes(n, Wonton::Entity_type::ALL,
                                      &adjnodes);
    std::vector<int> expnodes;
    for (int dx=-1; dx<=+1; ++dx) {
      if (dx == -1 && n / 9 == 0) continue;
      if (dx == +1 && n / 9 == 2) continue;
      for (int dy=-1; dy<=+1; ++dy) {
        if (dy == -1 && n / 3 % 3 == 0) continue;
        if (dy == +1 && n / 3 % 3 == 2) continue;
        for (int dz=-1; dz<=+1; ++dz) {
          if (dz == -1 && n % 3 == 0) continue;
          if (dz == +1 && n % 3 == 2) continue;
          expnodes.push_back(n + dx * 9 + dy * 3 + dz);
        }
      }
    }

    int expsize = expnodes.size();
    ASSERT_EQ(unsigned(expsize - 1), adjnodes.size());

    adjnodes.push_back(n);
    std::sort(adjnodes.begin(), adjnodes.end());
    for (int i=0; i<expsize; ++i)
      ASSERT_EQ(expnodes[i], adjnodes[i]);
  }

}


/*!
  @brief Unit test for basic routines in Flat_Mesh_Wrapper in 2D
 */
TEST(Flat_Mesh_Wrapper, basic_routines_2d) {
  Jali::MeshFactory mf(MPI_COMM_WORLD);
  mf.included_entities({Jali::Entity_kind::EDGE,
                        Jali::Entity_kind::FACE,
                        Jali::Entity_kind::WEDGE,
                        Jali::Entity_kind::CORNER});
  std::shared_ptr<Jali::Mesh> mesh = mf(0.0, 0.0, 1.0, 1.0, 4, 4);
  ASSERT_TRUE(mesh != NULL);
  Wonton::Jali_Mesh_Wrapper mesh_wrapper(*mesh);
  Wonton::Flat_Mesh_Wrapper<> mesh_flat;
  mesh_flat.initialize(mesh_wrapper);
  
  ASSERT_EQ(2, mesh_flat.space_dimension());

  // Test cells and nodes of flat mesh
  ASSERT_EQ(16, mesh_flat.num_owned_cells());
  ASSERT_EQ(16, mesh_flat.num_entities(Wonton::Entity_kind::CELL));
  ASSERT_EQ(25, mesh_flat.num_owned_nodes());
  ASSERT_EQ(25, mesh_flat.num_entities(Wonton::Entity_kind::NODE));

  // Check coordinates
  // List coordinates of cell 0 - others are equal to this
  // with a shift
  std::vector<Wonton::Point<2>> cell0Coords =
    {{0.0, 0.0},  {0.25, 0.0},  {0.25, 0.25},  {0.0, 0.25}};
  for (int c=0; c<16; ++c) {
    std::vector<Wonton::Point<2>> pplist;
    mesh_flat.cell_get_coordinates(c, &pplist);
    ASSERT_EQ(unsigned(4), pplist.size());
    double dx = (c / 4) * 0.25;
    double dy = (c % 4) * 0.25;
    for (int n=0; n<4; ++n) {
      ASSERT_EQ(cell0Coords[n][0] + dx, pplist[n][0]);
      ASSERT_EQ(cell0Coords[n][1] + dy, pplist[n][1]);
    }
  }

  // Test global ids
  std::vector<Wonton::GID_t>& gids = mesh_flat.get_global_cell_ids();
  for (int c=0; c<16; ++c)
    ASSERT_EQ(c, gids[c]);

  // Test centroids
  Wonton::Point<2> centroid;
  mesh_flat.cell_centroid(0, &centroid);
  for (int d=0; d<2; ++d)
    ASSERT_NEAR(0.125, centroid[d], TOL);

  // Test cell_volume()
  for (int c=0; c<16; ++c)
    ASSERT_NEAR(mesh_flat.cell_volume(c), 0.0625, TOL);

  // Test cell neighbors
  for (int c=0; c<16; ++c) {
    // Get my neighbors
    std::vector<int> adjcells;
    mesh_flat.cell_get_node_adj_cells(c, Wonton::Entity_type::ALL,
                                      &adjcells);
    // Add my own ID
    adjcells.push_back(c);
    // Which neighbors do I expect?
    // Loop through all possible neighbors, skipping if on boundary
    std::vector<int> expNeighbors;
    for (int dx=-1; dx<=+1; ++dx) {
      if (dx == -1 && c / 4 == 0) continue;
      if (dx == +1 && c / 4 == 3) continue;
      for (int dy=-1; dy<=+1; ++dy) {
        if (dy == -1 && c % 4 == 0) continue;
        if (dy == +1 && c % 4 == 3) continue;
        expNeighbors.push_back(c + dx * 4 + dy);
      }
    }
    int count = adjcells.size();
    ASSERT_EQ(expNeighbors.size(), unsigned(count));
    std::sort(adjcells.begin(), adjcells.end());
    for (int n=0; n<count; ++n)
      ASSERT_EQ(expNeighbors[n], adjcells[n]);
  }

  // Test node neighbors
  for (int n=0; n<25; ++n) {
    std::vector<int> adjnodes;
    mesh_flat.node_get_cell_adj_nodes(n, Wonton::Entity_type::ALL,
                                      &adjnodes);
    std::vector<int> expnodes;
    for (int dx=-1; dx<=+1; ++dx) {
      if (dx == -1 && n / 5 == 0) continue;
      if (dx == +1 && n / 5 == 4) continue;
      for (int dy=-1; dy<=+1; ++dy) {
        if (dy == -1 && n % 5 == 0) continue;
        if (dy == +1 && n % 5 == 4) continue;
        expnodes.push_back(n + dx * 5 + dy);
      }
    }

    int expsize = expnodes.size();
    ASSERT_EQ(unsigned(expsize - 1), adjnodes.size());

    adjnodes.push_back(n);
    std::sort(adjnodes.begin(), adjnodes.end());
    for (int i=0; i<expsize; ++i)
      ASSERT_EQ(expnodes[i], adjnodes[i]);
  }

}


