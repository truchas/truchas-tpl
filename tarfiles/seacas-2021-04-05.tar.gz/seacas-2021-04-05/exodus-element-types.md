See [Exodus Element Types](packages/seacas/libraries/exodus/include/exodus-element-types.md)
