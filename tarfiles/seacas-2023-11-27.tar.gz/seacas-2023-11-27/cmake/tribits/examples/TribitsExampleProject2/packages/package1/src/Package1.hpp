#ifndef PACKAGE1_HPP
#define PACKAGE1_HPP


#include <ostream>


namespace Package1 {

/** \brief . */
std::string itsme();

/** \brief . */
std::string deps();

} // namespace Package1


#endif // PACKAGE1_HPP
