#!/bin/sh
echo "exec_script.sh executed and returned this string"
