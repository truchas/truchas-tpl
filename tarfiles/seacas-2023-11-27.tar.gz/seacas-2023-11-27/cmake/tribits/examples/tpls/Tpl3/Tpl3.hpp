#ifndef TPL3_HPP
#define TPL3_HPP

#include <string>

namespace Tpl3 {

/** \brief . */
std::string itsme();

/** \brief . */
std::string deps();

} // namespace tpl3

#endif // TPL3_HPP
