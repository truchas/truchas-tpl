#ifndef SIMPLE_TPL_HPP
#define SIMPLE_TPL_HPP

#include <string>

namespace SimpleTpl {

/** \brief . */
double cube(const double &v);

/** \brief . */
std::string itsme();

} // namespace SimpleTpl

#endif // SIMPLE_TPL_HPP
