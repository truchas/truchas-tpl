#ifndef TPL2A_HPP
#define TPL2A_HPP

#include <string>

namespace Tpl2 {

/** \brief . */
std::string a_itsme();

/** \brief . */
std::string a_deps();

} // namespace tpl2

#endif // TPL2A_HPP
