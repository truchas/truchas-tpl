## Documentation
See SEACAS (including Exodus) documentation at http://sandialabs.github.io/seacas-docs/

## Installation
Installation directions are available at http://github.com/sandialabs/seacas

## Contact

Greg Sjaardema,
Sandia National Laboratories,
<gdsjaar@sandia.gov>, <gsjaardema@gmail.com>

We appreciate feedback from users of this package.  Please send
comments, suggestions, and bug reports to Greg Sjaardema
<gdsjaar@sandia.gov>, <gsjaardema@gmail.com>

