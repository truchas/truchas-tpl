/*
 * This file is part of the Ristra wonton project.
 * Please see the license file at the root of this repository, or at:
 *  https://github.com/laristra/wonton/blob/master/LICENSE
 */

// wonton
#include "wonton/support/wonton.h"
#include "wonton/swarm/swarm.h"
#include "wonton/swarm/swarm_state.h"
#include "wonton/mesh/simple/simple_mesh.h"
#include "wonton/mesh/simple/simple_mesh_wrapper.h"
#include "wonton/state/simple/simple_state.h"
#include "wonton/state/simple/simple_state_wrapper.h"
#include "wonton/support/Point.h"

// test framework
#include "gtest/gtest.h"

TEST(SwarmState, basic) {

  // set up a random swarm
  std::random_device device;
  std::mt19937 engine { device() };
  std::uniform_real_distribution<double> generator(0.0, 1.0);

  int const num_points = 10;
  Wonton::vector<Wonton::Point<3>> points(num_points);
  Wonton::Swarm<3> swarm;
  Wonton::SwarmState<3> state;

  for (int i = 0; i < num_points; i++) {
    // point coordinates are not always initialized in order
    // so enforce random number picking sequence
    double const noise[] = { generator(engine),
                             generator(engine),
                             generator(engine) };

    points[i] = Wonton::Point<3>(noise[0], noise[1], noise[2]);
  }

  // create state
  swarm.init(points);
  state.init(swarm);
  ASSERT_EQ(state.get_size(), num_points);

  // create state fields
  Wonton::vector<double> dbl_field1(num_points, 0.);
  Wonton::vector<double> dbl_field2(num_points, 0.);
  Wonton::vector<int>    int_field1(num_points, 0.);
  Wonton::vector<int>    int_field2(num_points, 0.);
  std::vector<double>     dbl_field3(num_points, 0.);
  std::vector<int>        int_field3(num_points, 0.);

  // fill in fields
  for (int i = 0; i < num_points; i++) {
    dbl_field1[i] = i + 0.10;
    dbl_field2[i] = i + 0.01;
    int_field1[i] = i + 10;
    int_field2[i] = i + 100;
  }

  std::copy(dbl_field1.begin(), dbl_field1.end(), dbl_field3.begin());
  std::copy(int_field1.begin(), int_field1.end(), int_field3.begin());

  // add the fields to the state
  state.add_field("d1", dbl_field1);
  state.add_field("d2", dbl_field2);
  state.add_field("i1", int_field1);
  state.add_field("i2", int_field2);
  state.add_field("d3", dbl_field3);
  state.add_field("i3", int_field3);

  // check that fields are correct
  int i3[num_points];
  double d3[num_points];

  auto d1 = state.get_field_dbl("d1");
  auto d2 = state.get_field_dbl("d2");
  auto i1 = state.get_field_int("i1");
  auto i2 = state.get_field_int("i2");
  state.copy_field("d3", d3);
  state.copy_field("i3", i3);

  for (int i = 0; i < num_points; i++) {
    ASSERT_EQ(i1[i], int_field1[i]);
    ASSERT_EQ(i2[i], int_field2[i]);
    ASSERT_EQ(i3[i], i1[i]);
    ASSERT_DOUBLE_EQ(d1[i], dbl_field1[i]);
    ASSERT_DOUBLE_EQ(d2[i], dbl_field2[i]);
    ASSERT_DOUBLE_EQ(d3[i], d1[i]);
  }

  // check names lists are correct
  auto dnames = state.get_field_names<double>();
  auto inames = state.get_field_names<int>();
  ASSERT_EQ(dnames.size(), unsigned(3));
  ASSERT_EQ(dnames[0], "d1");
  ASSERT_EQ(dnames[1], "d2");
  ASSERT_EQ(dnames[2], "d3");
  ASSERT_EQ(inames.size(), unsigned(3));
  ASSERT_EQ(inames[0], "i1");
  ASSERT_EQ(inames[1], "i2");
  ASSERT_EQ(inames[2], "i3");

  // check creation by size alone
  Wonton::SwarmState<3> state2(num_points);
  state2.add_field("d1", dbl_field1);
  auto d1p2 = state2.get_field_dbl("d1");
  ASSERT_EQ(d1p2.size(), unsigned(num_points));
}


/*!
  @brief Unit test for constructor with Simple_State_Wrapper in 3D using cells
*/
TEST(SwarmState, Simple_State_Wrapper) {

  Wonton::Simple_Mesh mesh(0.0, 0.0, 0.0, 1.0, 1.0, 1.0, 2, 2, 2);
  Wonton::Simple_Mesh_Wrapper mesh_wrapper(mesh);
  Wonton::Simple_State mesh_state(std::make_shared<Wonton::Simple_Mesh>(mesh));

  int nb_cells = mesh_wrapper.num_owned_cells();
  int nb_nodes = mesh_wrapper.num_owned_nodes();
  std::vector<double> cell_field(nb_cells, 1.);
  std::vector<double> node_field(nb_nodes, 2.);

  mesh_state.add("cf1", Wonton::CELL, cell_field.data());
  mesh_state.add("nf1", Wonton::NODE, node_field.data());
  Wonton::Simple_State_Wrapper state_wrapper(mesh_state);

  {
    Wonton::SwarmState<3> state(state_wrapper, Wonton::CELL);

    auto intnames = state.get_field_names<int>();
    auto dblnames = state.get_field_names<double>();

    ASSERT_EQ(state.get_size(), nb_cells);
    ASSERT_EQ(intnames.size(), unsigned(0));
    ASSERT_EQ(dblnames.size(), unsigned(1));
    ASSERT_EQ(dblnames[0], "cf1");

    auto field = state.get_field_dbl("cf1");
    for (int i = 0; i < nb_cells; i++)
      ASSERT_EQ(field[i], 1.0);
  }

  {
    Wonton::SwarmState<3> state(state_wrapper, Wonton::NODE);

    auto intnames = state.get_field_names<int>();
    auto dblnames = state.get_field_names<double>();

    ASSERT_EQ(state.get_size(), nb_nodes);
    ASSERT_EQ(intnames.size(), unsigned(0));
    ASSERT_EQ(dblnames.size(), unsigned(1));
    ASSERT_EQ(dblnames[0], "nf1");

    auto field = state.get_field_dbl("nf1");
    for (int i=0; i < nb_nodes; i++)
      ASSERT_EQ(field[i], 2.0);
  }
}

