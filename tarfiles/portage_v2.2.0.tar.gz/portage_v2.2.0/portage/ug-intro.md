/*
This file is part of the Ristra portage project.
Please see the license file at the root of this repository, or at:
    https://github.com/laristra/portage/blob/master/LICENSE
*/

<!-- CINCHDOC DOCUMENT(User Guide) CHAPTER(Introduction) -->

# Introduction

Portage is...
